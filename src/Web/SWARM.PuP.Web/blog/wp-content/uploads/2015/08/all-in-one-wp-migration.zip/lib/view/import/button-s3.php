<a href="https://servmask.com/products/amazon-s3-extension" target="_blank"><?php _e( 'Amazon S3', AI1WM_PLUGIN_NAME ); ?></a>
