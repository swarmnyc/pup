<div class="ai1wm-overlay"></div>
<div id="ai1wm-export-modal" class="ai1wm-modal">
	<ul>
		<li id="ai1wm-export-status">
			<i class="ai1wm-loader"></i>
			<p>
				<?php _e( 'Please wait while we start the export process...', AI1WM_PLUGIN_NAME ); ?>
			</p>
		</li>
	</ul>
	<button id="ai1wm-cancel-export" class="ai1wm-button-red">
		<i class="ai1wm-icon-notification"></i> <?php _e( 'Stop export', AI1WM_PLUGIN_NAME ); ?>
	</button>
</div>
